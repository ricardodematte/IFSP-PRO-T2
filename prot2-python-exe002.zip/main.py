nome = input("Digite seu nome:\n")
print("Benvindo,", nome," !!!")